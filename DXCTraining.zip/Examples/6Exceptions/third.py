#uname=None
#uname=''
#uname=0
#uname=[]
#uname={}
uname=()

if(uname):
	print('Truth value')
else:
	print('Falsy Value')


print(isinstance(uname,list))