
a()

def a():
	print('a')


