fo = open("myFirst.xls", "a")
fo.write('This is my \t sample data \t to be written \t to the file')
fo.close()




















'''
fo.seek(0,0)
print(fo.read(10))
'''