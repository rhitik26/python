for letter in 'Python':     # First Example
   print 'Current Letter :', letter

fruits = ['banana', 'apple',  'mango']
for fruit in fruits:        # Second Example
   print 'Current fruit :', fruit
   
for n in range(10,20,2):
	print n
else:
	print 'for loop done'
	
	
a=10
b=20
a,b= b,a
print a
print b