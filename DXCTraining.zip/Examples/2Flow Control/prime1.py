num,i=21,2
while i<num:
	if(num%i==0):
		print('Not Prime!')
		break;
	i+=1
else:
	print('PRIME')
