a=50
if a>=0 and a<=100:
	if a<=40:
		print('Fail')
	elif a<=60:
		print('Third')
	elif a<=80:
		print('Second')
	else:
		print('First')
else:
	print('invalid!!')