def add(a,b):
	return a+b

print(add(1,2))
print(add(10,20))
print(add(100,2000))
	
print((lambda name1,name2: "Hi "+name1+" and "+name2)("Sachin","Saurav"))
print((lambda name1,name2: "Hi "+name1+" and "+name2)("Sachin","Rahul"))
print((lambda name1,name2: "Hi "+name1+" and "+name2)("Rahul","Saurav"))
