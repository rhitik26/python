i= 11
j= "100.12"
l= i+int(j)
print l