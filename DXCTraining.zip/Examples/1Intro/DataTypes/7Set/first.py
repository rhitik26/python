a={7,6,5,4,5,7,8,9}
print(a)
print(type(a))