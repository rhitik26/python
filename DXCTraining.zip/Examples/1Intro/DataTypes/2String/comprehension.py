d1={'fname':'Sachin'}
d2={'lname':'Tendulkar'}
d1.update(d2)
print(d1)
print(d2)