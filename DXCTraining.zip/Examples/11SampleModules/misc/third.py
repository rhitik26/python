a="Hello this is global"
b=[]
b.append("HI")

class A:
    i=3
    def sayHi(self):
        print b