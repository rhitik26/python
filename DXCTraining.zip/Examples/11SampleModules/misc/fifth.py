x='HELLO PYTHON'
y='PYT'
z='HELL'
if y not in x and z not in x :
    print 'IT IS  NOT THERE'
else:
    print 'IT IS THERE'