from datetime import date;
dToday=date.today()
print(dToday.isoformat())

print(dToday.strftime("%Y-%m-%d"))