import os
os.system('echo "hi"')
os.system('dir')
os.system('calc')
os.system('notepad first.py')
os.system('python first.py')
