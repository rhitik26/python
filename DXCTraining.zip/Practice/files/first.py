with open('demo.txt','wb') as fo:
	fo.write("Hello Sachin \n".encode())
	fo.write("Hello Saurav \n".encode())
	fo.write("Hello Rahul \n".encode())
