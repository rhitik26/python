class person:
	team="India"
	def sayhi(spiderman):
		print("Hi "+spiderman.fname+" "+spiderman.lname)
	def __init__(o,f,l):
		o.fname=f
		o.lname=l
		
def demo():
	print("This is demo!")
	
data="Hello World!"
if __name__=="__main__":
	print("Hello World!")
	print("Hello World!")
	print("Hello World!")
	print("Hello World!")
	