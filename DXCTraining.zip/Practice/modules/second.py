from first import demo as d,person as p
d()
p1=p("Sachin","Tendulkar")
p1.sayhi()