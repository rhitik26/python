#sequence operations
#slicing
data="Hello Python"
print(data[:4])#4th index is excluded
print(data[:5])#5th index is excluded
print(data[6:-1])#-1 is excluded
print(data[6:])#last is included

