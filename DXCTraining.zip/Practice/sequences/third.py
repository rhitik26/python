#sequence operations
#stepping
data="Hello Python"
print(data[4:0:-1])
print(data[4::-1])
