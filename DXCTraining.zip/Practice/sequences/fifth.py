# data=1,
data=(1,)
print(type(data))
