data=1,2,2.3,True,None,"Hello"
print(type(data))
data[1]=False
print(data)