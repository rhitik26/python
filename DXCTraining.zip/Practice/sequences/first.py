#sequence operations
#indexing
data="Hello Python"
print(data[0])#first
print(data[1])
print(data[2])
print(data[-1])#last
print(data[-3])
