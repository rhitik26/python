d1={
	'fname':"Sachin",
	'lname':'Tendulkar'
	}
li=list(d1.values())
print(li)
