data=range(10)
print(type(data))
for d in data:
	print(d)


	   
	   
	   
