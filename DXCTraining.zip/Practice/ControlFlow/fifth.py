print("Hello World!",end=";")
print("Hello World!",end=";")
print("Hello World!",end=";")

	   
	   
	   
