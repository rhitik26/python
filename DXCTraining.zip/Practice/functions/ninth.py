# a,b=int(input()),int(input())
a,b=10,20

a,b=[b,a]
