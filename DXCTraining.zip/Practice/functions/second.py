def sayhello(name1,name2,name3):
	print("Hi "+name1+" "+name2+" "+name3)
bye=sayhello
print(type(bye))
bye("A","B","C")