
def outer():
	def inner():
		data="Hello World"
		
	inner()
	print(data)
		
outer()
