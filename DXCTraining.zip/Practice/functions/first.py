def sayhi():
	print("Hi All")
sayhi()
sayhi()
sayhi()
def sayhello(name1,name2):
	return("Hi "+name1+" "+name2)
data =sayhello("Sachin","Saurav")
print("Data: ",data)
