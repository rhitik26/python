def add(*spiderman):
	# print(type(spiderman))
	# print(spiderman)
	sum=0
	for x in spiderman:
		sum+=x
	print(spiderman,sum)


add(1,2)	
add(1,2,3)	
add(1,2,3,4)	
print("Hello World!")