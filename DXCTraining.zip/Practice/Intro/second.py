#Dynamically typed
data ='123.12'
print(int(float(data)))
