data ="Hello World!"
print(data)
temp=data
print(temp)
temp= "Hello Galaxy"
print(data)
